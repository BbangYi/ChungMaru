# Chungmaru 성능 실험 결과보고서 초안

## 1. 실험 목적

본 실험의 목적은 유해 텍스트가 화면에 노출된 뒤 사용자가 인지하기 전에 마스킹이 적용될 수 있는지 확인하는 것이다. 목표 지표는 이상적으로 `first provisional mask <= 200ms`이며, 이를 위해 Chrome 확장 프로그램 경로와 Android Accessibility 기반 Google 모바일 경로를 각각 측정했다.

## 2. 제출 로그 구성

이번 정리본은 원본 로그와 요약 파일을 분리했다. Chrome 확장 프로그램 실험은 `raw/chrome/chrome-e2e-samples.csv`에 10,000 row 단위 측정 로그가 있으며, Android Google 모바일 실험은 `raw/android-pi/android-google-method-runs-slim.csv`와 `raw/android-pi/android-google-method-runs.csv`에 방법별 측정 로그가 있다. 자동화 실패/성공 이력은 `summary/android-automation-history.csv`에 정리했다.

## 3. Chrome 확장 프로그램 경로 결과

Chrome 확장 프로그램 경로는 10,000 row 기준으로 가장 신뢰할 수 있는 성능 근거다.

- 총 row 수: 10,000
- `total_to_mask_ms` median: 68ms
- `total_to_mask_ms` p95: 203ms
- `total_to_mask_ms` p99: 270ms
- `total_to_mask_ms` max: 2161ms
- 100ms 이하: 8,701/10,000 rows
- 250ms 이하: 9,837/10,000 rows
- `first_mask_ms` median: 2ms
- `first_mask_ms` p95: 32ms

해석하면, Chrome 경로에서는 최초 마스크 적용 자체는 매우 빠르게 동작한다. 다만 전체 완료 시간은 backend roundtrip에 의해 지배되며, 일부 outlier가 존재한다. 따라서 “초기 보호 마스크는 빠르게 적용되고, 최종 판정 확인은 backend 왕복 시간에 따라 지연될 수 있다”라고 해석하는 것이 정확하다.

## 4. Android Google 모바일 경로 결과

Android Google 모바일 경로는 5개의 방법을 실험했지만, 아직 1000 row 수준의 안정적인 비교 데이터는 확보하지 못했다.

- 유효 latency row 수: 5
- `first_mask_ms` best: 554ms
- `first_mask_ms` latest: 3236ms
- `receive_to_mask_ms` avg: 112.6ms
- `collect_ms` avg: 437.6ms
- `backend_api_ms` avg: 2568.6ms

Android 결과에서 중요한 점은 end-to-end `first_mask_ms`가 아직 목표치인 200ms에 도달하지 못했다는 것이다. 반면, 이벤트가 수신된 이후 overlay 적용까지의 내부 경로는 평균 100ms대 수준으로 확인된다. 따라서 병목은 마스크를 화면에 그리는 단계보다 Android/Chrome Accessibility 이벤트 전달 지연과 backend API 확인 경로에 있다.

## 5. 개선되었다고 말할 수 있는 부분

1. Chrome 확장 프로그램 경로에서는 10,000 row 기준으로 최초 마스크 적용이 p95 기준 32ms 수준으로 동작했다. 이는 사용자 인지 전 보호 가능성에 가장 가까운 근거다.
2. Chrome 전체 완료 시간은 median 68ms, p95 203ms로 200ms 목표에 근접했다.
3. Android에서는 이벤트 수신 이후 overlay 적용 경로가 평균 112.6ms로 측정되어, 내부 렌더링/마스킹 적용 자체가 주 병목은 아님을 확인했다.
4. Android 방법 실험 중 collect 단계는 best 309ms, worst 530ms로 차이가 있어 최적화 여지가 확인됐다.

## 6. 아직 부족한 부분과 한계

Android Google 모바일 경로는 현재 제출 시점에서 “성공적으로 200ms 이내 마스킹을 달성했다”고 주장하기 어렵다. 특히 `first_mask_ms`가 3초대인 결과가 많으며, 자동화는 데스크톱 전원/SSH 연결 안정성 문제와 emulator 준비 문제로 여러 번 실패했다. 이 부분은 실패가 아니라, 모바일 환경에서의 실제 병목 위치를 확인한 결과로 정리하는 것이 맞다.

또한 Android 표본은 5개 유효 row에 그쳐 통계적 비교에는 부족하다. 따라서 Android 결과는 “최종 성능 입증”이 아니라 “병목 분석 및 다음 개선 방향”으로 제출해야 한다.

## 7. 다음 개선 방향

- Android 측정 자동화를 안정화해 방법별 1000 row 이상을 수집한다.
- backend 확인 전에 로컬 fast decision을 먼저 적용하고, backend는 final confirm으로 분리한다.
- Android Accessibility 이벤트 도달 지연을 줄이기 위해 Google/Chrome 화면 전체 스캔이 아니라 활성 root/viewport 중심으로 후보 수집을 제한한다.
- backend roundtrip outlier를 줄이기 위해 warmup, persistent connection, cache, batch policy를 고정한다.

## 8. 결론

이번 실험은 모든 환경에서 200ms 목표를 완전히 달성했다기보다는, Chrome 확장 프로그램 경로에서는 목표에 가까운 성능을 확인했고 Android Google 모바일 경로에서는 병목이 어디에서 발생하는지 구체적으로 확인한 단계다. 즉, 결과는 무의미한 실패가 아니라 구현 방향을 나누는 근거다. 웹/확장 프로그램 경로는 실사용 가능성 검증 근거로, Android 경로는 플랫폼 병목 분석과 후속 개선 과제로 제시하는 것이 타당하다.
