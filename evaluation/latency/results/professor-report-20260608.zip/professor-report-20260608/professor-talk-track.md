# 교수님 설명용 요약

교수님께는 다음처럼 말하는 것이 가장 안전합니다.

1. Chrome 확장 프로그램 경로는 10,000 row 로그를 확보했고, 최초 마스크 적용은 p95 32ms 수준으로 매우 빠르게 나왔습니다.
2. 전체 `total_to_mask_ms`는 median 68ms, p95 203ms로 200ms 목표에 거의 근접했지만, backend roundtrip outlier 때문에 p95가 약간 넘었습니다.
3. Android Google 모바일 경로는 아직 성공 주장 단계가 아닙니다. 유효 row가 5개뿐이고 first mask가 3초대로 나오는 경우가 많았습니다.
4. 대신 Android 로그로 확인한 핵심은, 마스크를 그리는 단계 자체보다 Accessibility 이벤트 전달과 backend API 확인이 병목이라는 점입니다.
5. 그래서 보고서에서는 “웹 확장 경로는 성능 가능성을 확인했고, Android 경로는 병목 분석과 후속 개선 방향을 제시했다”라고 정리하는 것이 맞습니다.

제출 시 같이 보여줄 파일은 `professor-report-draft.md`, `summary/chrome-overall-stats.csv`, `summary/android-method-comparison-ko.csv`, `summary/improvement-claims-and-limitations.csv`, `videos/chrome-extension-demo.mp4`, `videos/android-google-latest-demo.mp4`입니다.
