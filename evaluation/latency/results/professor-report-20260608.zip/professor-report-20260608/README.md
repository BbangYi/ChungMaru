# Chungmaru latency evidence package

Generated: 2026-06-08 11:29 KST

이 폴더는 교수님께 제출/공유하기 위한 성능 로그 정리본입니다. 원본 로그와 가공 요약을 분리했습니다.

## 핵심 파일

- `professor-report-draft.md`: 한국어 결과보고서 초안
- `professor-talk-track.md`: 교수님께 설명할 때 사용할 짧은 설명문
- `summary/chrome-overall-stats.csv`: Chrome 확장 프로그램 10,000 row 전체 통계
- `summary/chrome-scenario-batch-summary.csv`: Chrome scenario/batch별 통계
- `summary/android-method-comparison-ko.csv`: Android Google 5개 방법 비교
- `summary/improvement-claims-and-limitations.csv`: 주장 가능한 개선점과 한계
- `summary/android-automation-history.csv`: Pi/desktop 자동화 성공/실패 이력
- `raw/chrome/`: Chrome 원본 CSV/로그
- `raw/android-pi/`: Pi 공유 SSD에서 가져온 Android 원본 CSV/상태 로그
- `videos/`: 제출용 데모 영상과 캡처

## 해석 원칙

- Chrome 확장 프로그램 경로는 10,000 row 근거가 있으므로 주 성능 근거로 사용합니다.
- Android Google 모바일 경로는 아직 표본이 5개라 성공 주장보다는 병목 규명 근거로 사용합니다.
- Android에서 end-to-end 200ms 달성은 아직 확인되지 않았습니다. 대신 이벤트 수신 이후 overlay 적용 자체가 200ms 안쪽인 지표는 확인됐습니다.
